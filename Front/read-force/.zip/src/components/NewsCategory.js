const NewsCategory = [
  { value: '', label: '모두' },
  { value: 'POLITICS', label: '정치' },
  { value: 'ECONOMY', label: '경제' },
  { value: 'SOCIETY', label: '사회' },
  { value: 'CULTURE', label: '생활/문화' },
  { value: 'SCIENCE', label: 'IT/과학' },
  { value: 'ETC', label: '기타' },
];

export default NewsCategory;
